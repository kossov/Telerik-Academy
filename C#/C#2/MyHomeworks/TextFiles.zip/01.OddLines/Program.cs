﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.OddLines
{
    class OddLines
    {
        static void Main()
        {
            const string PATH = "../../OddLines.txt";

            Console.WriteLine("> Prints odd lines of text file...\n");

            using (StreamReader reader = new StreamReader(PATH))
            {
                int lineCount = 1;

                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();

                    if (lineCount++ % 2 != 0) Console.WriteLine(line);
                }
            }
        }
    }
}
