﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.ConcatenateTextFiles
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Text.Encoding encodingCyr = System.Text.Encoding.GetEncoding(1251);

            try
            {
                string fileOne = @"..\..\FileOne.txt";
                string fileTwo = @"..\..\FileTwo.txt";

                StreamReader readOne = new StreamReader(fileOne, encodingCyr);
                StreamReader readTwo = new StreamReader(fileTwo, encodingCyr);

                string readFileOne = "";
                string readFileTwo = "";

                using (readOne)
                {
                    readFileOne = readOne.ReadToEnd();
                }

                using (readTwo)
                {
                    readFileTwo = readTwo.ReadToEnd();
                }

                StreamWriter newFile = new StreamWriter(@"..\..\New File.txt", true, encodingCyr);

                using (newFile)
                {
                    newFile.WriteLine(readFileOne);
                    newFile.WriteLine(readFileTwo);
                }


            }
            catch (FileLoadException)
            {
                Console.WriteLine("Files not found.");
            }
        }
    }
}
