﻿/* Write a program that converts a string to a sequence of C# Unicode character literals.
Use format strings.
Example:

input	output
Hi!	\u0048\u0069\u0021 */
namespace _10.UnicodeCharacters
{
    using System;
    class ConvertingToUnicodeLiterals
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a string: ");
            string input = Console.ReadLine();
            foreach (char symbol in input)
            {
                Console.Write(String.Format("\\u{0:X4}", (int)symbol));
            }
            Console.WriteLine();
        }
    }
}
