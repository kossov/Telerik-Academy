﻿/* Write a program that extracts from a given text all sentences containing given word.
Example:

The word is: in

The text is: We are living in a yellow submarine. We don't have anything else. Inside the submarine is very tight. So we are drinking all the day. We will move out of it in 5 days.

The expected result is: We are living in a yellow submarine. We will move out of it in 5 days.

Consider that the sentences are separated by . and the words – by non-letter symbols. */
namespace _08.ExtractSentences
{
    using System;
    using System.Text;
    class ExtractSentencesByGivenWord
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your text: ");
            string input = Console.ReadLine();
            Console.Write("Enter the search word: ");
            string word = Console.ReadLine();
            word = word.Insert(0, " ");
            Console.WriteLine(ExtractingSentences(input, word));
        }
        static string ExtractingSentences(string input, string word)
        {
            StringBuilder result = new StringBuilder();
            int wordPosition = 0, temp = 0, startCutPosition = -1, endCutPosition = 0;
            while (temp >= 0)
            {
                temp = input.IndexOf(word, wordPosition);
                if (temp == -1)
                    break;
                wordPosition = temp + word.Length;
                while (startCutPosition < 0)
                {
                    startCutPosition = input.LastIndexOf(".", wordPosition-1);
                    if (startCutPosition < 0)
                    {
                        startCutPosition = 0;
                    }
                    else
                        startCutPosition = startCutPosition + 1;
                }
                endCutPosition = input.IndexOf(".", wordPosition);
                result.Append(input, startCutPosition, endCutPosition - startCutPosition + 1);
                startCutPosition = -1;
            }
            return result.ToString();
        }
    }
}
/*                     try
                    {
                        startCutPosition = input.LastIndexOf(". ",0,wordPosition);
                    }
                    catch (Exception)
                    {
                        startCutPosition = 0;
                        break;
                    }
                    finally
                    {
                        if (startCutPosition != 0)
                        {
                            startCutPosition = startCutPosition + 2;
                        }
                    } */