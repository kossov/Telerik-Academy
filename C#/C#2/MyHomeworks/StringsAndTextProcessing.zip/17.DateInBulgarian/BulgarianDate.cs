﻿/* Write a program that reads a date and time given in the format: day.month.year hour:minute:second and prints the date and time after 6 hours and 30 minutes (in the same format) along with the day of week in Bulgarian. */
namespace _17.DateInBulgarian
{
    using System;
    using System.Globalization;
    using System.Threading;
    class BulgarianDate
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.Unicode;
            Thread.CurrentThread.CurrentCulture = new CultureInfo("bg-BG");
            string format = "d.M.yyyy H:m:s";
            Console.Write("Enter [day.month.year] [hour:minute:second]: ");
            CultureInfo useThis = CultureInfo.GetCultureInfo("bg-BG");
            DateTime date = DateTime.ParseExact(Console.ReadLine(), format, useThis);
            date = date.AddHours(6).AddMinutes(30);
            Console.WriteLine(date.ToString("dd.MM.yyyy HH:mm:ss dddd"), useThis);
        }
    }
}
