﻿/* Write a program that reads a string, reverses it and prints the result at the console.
Example:

input	output
sample  elpmas */
namespace _02.ReverseString
{
    using System;
    class Reversing
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a string: ");
            char[] input = Console.ReadLine().ToCharArray();
            Array.Reverse(input);
            Console.WriteLine(new string(input));
        }

    }
}
