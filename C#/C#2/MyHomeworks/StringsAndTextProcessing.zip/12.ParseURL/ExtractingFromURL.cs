﻿/* Write a program that parses an URL address given in the format: [protocol]://[server]/[resource] and extracts from it the [protocol], [server] and [resource] elements.
Example:

URL	Information
http://telerikacademy.com/Courses/Courses/Details/212	[protocol] = http 
[server] = telerikacademy.com 
[resource] = /Courses/Courses/Details/212 */
namespace _12.ParseURL
{
    using System;
    class ExtractingFromURL
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the URL: ");
            string input = Console.ReadLine();
            string protocol = ExtractingProtocol(input);
            string server = ExtractingServer(input);
            string resource = ExtractingResource(input);
            Console.WriteLine("[protocol] = {0}\n[server] = {1}\n[resource] = {2}",protocol,server,resource);
        }
        private static string ExtractingProtocol(string input)
        {
            string result = string.Empty;
            int endOfProtocol = input.IndexOf(':', 0);
            return result = input.Substring(0, endOfProtocol);
        }
        private static string ExtractingServer(string input)
        {
            string result = string.Empty;
            int endOfServer = 0;
            for (int i = 0; i <= 2; i++)
            {
                endOfServer = input.IndexOf("/", endOfServer + i);
            }
            int temp = input.LastIndexOf('/', endOfServer - 1) + 1;
            return result = input.Substring(temp, endOfServer - temp);
        }
        private static string ExtractingResource(string input)
        {
            string result = string.Empty;
            int startOfResource = 0;
            for (int i = 0; i < 3; i++)
            {
                startOfResource = input.IndexOf('/', startOfResource + i);
            }
            return result = input.Substring(startOfResource);
        }
    }
}
