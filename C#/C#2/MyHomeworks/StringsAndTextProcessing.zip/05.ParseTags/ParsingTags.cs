﻿/* You are given a text. Write a program that changes the text in all regions surrounded by the tags <upcase> and </upcase> to upper-case.
The tags cannot be nested.
Example: We are living in a <upcase>yellow submarine</upcase>. We don't have <upcase>anything</upcase> else.

The expected result: We are living in a YELLOW SUBMARINE. We don't have ANYTHING else. */
namespace _05.ParseTags
{
    using System;
    class ParsingTags
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a text: ");
            string input = Console.ReadLine();
            Console.WriteLine(Counting(input));
        }
        static string Counting(string input)
        {
            int counter = 0, temp = 0, position = 0;
            while (true)
            {
                temp = input.IndexOf("<upcase>", position);
                if (temp >= 0)
                {
                    position = temp + 8;
                    counter = input.IndexOf("</upcase>", position);
                    string tempString = input.Substring(position, counter - position);
                    input = input.Remove(temp, 8); // removing <upcase>
                    input = input.Remove(counter-8, 9); // removing </upcase>
                    input = input.Replace(tempString, tempString.ToUpper());
                }
                else if (temp < 0)
                    break;
            }
            return input;
        }
    }
}
