﻿/* Write a program that reverses the words in given sentence.
Example:

input	                                output
C# is not C++, not PHP and not Delphi!	Delphi not and PHP, not C++ not is C#! */
namespace _13.ReverseSentence
{
    using System;
    using System.Linq;
    using System.Text;
    class ReversingSentence
    {
        static string[] punctuation = new string[] { ",", "!", "?", ".", ":", "/", "-" };
        static void Main(string[] args)
        {
            Console.Write("Enter a sentence: ");
            string input = Console.ReadLine();
            string[] separatedInput = Separated(input);

            string[] result = new string[separatedInput.Length];
            FillingThePunctuation(separatedInput,result);
            ReverseWords(separatedInput, result);
            Console.WriteLine(JoiningSentence(result).TrimStart());
        }
        static string[] Separated(string input)
        {
            string[] result = new string[input.Length];
            foreach (string element in punctuation)
            {
                input = input.Replace(element, (" " + element + " "));
            }
            return result = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        }
        static void FillingThePunctuation(string[] separatedInput, string[] result)
        {
            for (int i = 0; i < separatedInput.Length; i++)
            {
                if (punctuation.Contains(separatedInput[i]))
                    result[i] = separatedInput[i];
            }
        }
        static void ReverseWords(string[] separatedInput, string[] result)
        {
            for (int i = 0, j=separatedInput.Length-1; i < separatedInput.Length && j>=0; i++,j--)
            {
                if (punctuation.Contains(separatedInput[j]))
                    j--;
                if (result[i] != null)
                    i++;
                    result[i] = separatedInput[j];
            }
        }
        static string JoiningSentence(string[] result)
        {
            StringBuilder finalResult = new StringBuilder();
            foreach (var item in result)
            {
                if (punctuation.Contains(item))
                    finalResult.Append(item);
                else
                    finalResult.Append(" "+item);
            }
            return finalResult.ToString();
        }
    }
}
