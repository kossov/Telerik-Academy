﻿/* We are given a string containing a list of forbidden words and a text containing some of these words.
Write a program that replaces the forbidden words with asterisks.
Example text: Microsoft announced its next generation PHP compiler today. It is based on .NET Framework 4.0 and is implemented as a dynamic language in CLR.

Forbidden words: PHP, CLR, Microsoft

The expected result: ********* announced its next generation *** compiler today. It is based on .NET Framework 4.0 and is implemented as a dynamic language in ***. */
namespace _09.ForbiddenWords
{
    using System;
    using System.Text;
    class ReplacingForbiddenWords
    {
        static void Main(string[] args)
        {
            Console.Write("Enter text: ");
            string input = Console.ReadLine();
            Console.Write("Enter forbidden words: ");
            string[] words = (Console.ReadLine()).Split(new string[] { ", " }, StringSplitOptions.None);
            Console.WriteLine(ResultText(input, words));
        }
        static string ResultText(string input, string[] words)
        {
            StringBuilder result = new StringBuilder(input);
            int tempPosition = 0;
            for (int i = 0; i < words.Length; i++)
            {
                while (tempPosition >= 0)
                {
                    tempPosition = input.IndexOf(words[i], tempPosition);
                    if (tempPosition < 0)
                        break;
                    result.Replace(words[i], new string('*',words[i].Length), tempPosition, words[i].ToString().Length);
                    tempPosition++;
                }
                tempPosition = 0;
            }
            return result.ToString();
        }
    }
}
