﻿/* Write a program that encodes and decodes a string using given encryption key (cipher).
The key consists of a sequence of characters.
The encoding/decoding is done by performing XOR (exclusive or) operation over the first letter of the string with the first of the key, the second – with the second, etc. When the last key character is reached, the next is the first. */
namespace _07.EncodeDecode
{
    using System;
    using System.Text;
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a string: ");
            string input = Console.ReadLine();
            Console.Write("Enter cipher: ");
            string cipher = Console.ReadLine();
            string encoding = Encoding(input, cipher);
            Decoding(encoding, cipher);
        }
        static string Encoding(string input, string cipher)
        {
            StringBuilder encodingResult = new StringBuilder();
            for (int  i= 0, countingCipher = 0; i < input.Length; i++,countingCipher++)
            {
                if (countingCipher == cipher.Length-1)
                    countingCipher = 0;
                encodingResult.Append((char)(cipher[countingCipher] ^ input[i]));
            }
            Console.WriteLine("We encoded your text: "+encodingResult.ToString());
            return encodingResult.ToString();
            
        }
        static void Decoding(string encodingResult, string cipher)
        {
            StringBuilder decodingResult = new StringBuilder();
            for (int i = 0, countingCipher = 0; i < encodingResult.ToString().Length; i++, countingCipher++)
            {
                if (countingCipher == cipher.Length-1)
                    countingCipher = 0;
                decodingResult.Append((char)(cipher[countingCipher] ^ encodingResult[i]));
            }
            Console.WriteLine("We decoded the encoding: " + decodingResult.ToString());
        }
    }
}
