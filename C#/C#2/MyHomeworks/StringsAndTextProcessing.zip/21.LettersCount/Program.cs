﻿/* Write a program that reads a string from the console and prints all different letters in the string along with information how many times each letter is found. */
namespace _21.LettersCount
{
    using System;
using System.Collections.Generic;
    class Program
    {
        static List<char> existsOnce = new List<char>(); 
        static void Main(string[] args)
        {
            Console.Write("Enter a string: ");
            string input = Console.ReadLine();
            foreach (char item in input)
            {
                if (existsOnce.Contains(item) == true)
                    continue;
                else
                    existsOnce.Add(item);
            }
            PrintingAllLetters(input,existsOnce);

        }
        static void PrintingAllLetters(string input, List<char> existsOnce)
        {
            for (int i = 0; i < existsOnce.Count; i++)
            {
                Console.Write(existsOnce[i] + " - ");
                char temp = existsOnce[i];
                int count = 0;
                foreach (char element in input)
                {
                    if (temp == element)
                    {
                        count++;
                    }
                }
                Console.WriteLine("{0} times", count);
            }
        }

    }
}
