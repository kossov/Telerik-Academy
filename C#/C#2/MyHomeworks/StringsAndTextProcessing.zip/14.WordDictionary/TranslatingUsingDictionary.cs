﻿/* A dictionary is stored as a sequence of text lines containing words and their explanations.
Write a program that enters a word and translates it by using the dictionary.
Sample dictionary:

input	output
.NET	platform for applications from Microsoft
CLR	managed execution environment for .NET
namespace	hierarchical organization of classes */
namespace _14.WordDictionary
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    class TranslatingUsingDictionary
    {
        static Dictionary<string,string> dictionary = new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase)
        { 
            {".NET","platform for applications from Microsoft"},
            {"CLR", "managed execution environment for .NET"},
            {"namespace", "hierarchical organization of classes"}
        }
            ;
        static void Main(string[] args)
        {
            Console.WriteLine("The dictionary contains the following words:");
            Console.WriteLine(string.Join(", ",dictionary.Keys));
            Console.Write("Enter a word: ");
            string input = Console.ReadLine();
            Console.WriteLine(dictionary.ContainsKey(input) ? string.Format("{0}",dictionary[input]) : "The word does not exist in that dictionary!");
        }
    }
}
