﻿/* Write a program that reads a string from the console and replaces all series of consecutive identical letters with a single one.
Example:

input	                output
aaaaabbbbbcdddeeeedssaa	abcdedsa */
namespace _23.SeriesOfLetters
{
    using System;
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a string: ");
            string input = Console.ReadLine();
            Console.WriteLine(RemovingIdenticalLetters(input));
        }
        static string RemovingIdenticalLetters(string input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                if (i == input.Length - 1)
                    break;
                if (input[i] == input[i + 1])
                {
                    int count = 0;
                    for (int j = i + 1; j < input.Length; j++)
                    {
                        if (input[i] == input[j])
                        {
                            count++;
                            continue;
                        }
                        else
                            break;
                    }
                    input = input.Remove(i, count);
                }

            }
            return input;
        }
    }
}
