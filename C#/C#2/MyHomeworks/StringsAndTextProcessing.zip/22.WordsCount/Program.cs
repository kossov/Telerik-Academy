﻿/* Write a program that reads a string from the console and lists all different words in the string along with information how many times each word is found. */
namespace _22.WordsCount
{
    using System;
    using System.Collections.Generic;
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a string: ");
            string input = Console.ReadLine();
            List<string> allWords = new List<string>();
            allWords = AllWords(input);
            PrintingWords(allWords);
        }
        static List<string> AllWords(string input) // could have done all of this with just one .Split(" ") but.. i typed it already
        {
            List<string> result = new List<string>();
            int start = 0, end = 0;
            for (int i = 0; i < input.Length; i++)
            {
                end = input.IndexOf(' ', start);
                if (end == -1)
                {
                    result.Add(input.Substring(start, input.Length - start));
                    break;
                }
                result.Add(input.Substring(start, end - start));
                start = end + 1;
            }
            return result;
        }

        static void PrintingWords(List<string> allWords)
        {
            List<string> existsOnce = new List<string>();
            foreach (string word in allWords)
            {
                if (existsOnce.Contains(word) == true)
                    continue;
                else
                    existsOnce.Add(word);
            }
            for (int i = 0; i < existsOnce.Count; i++)
            {
                Console.Write(existsOnce[i] + " - ");
                string temp = existsOnce[i];
                int count = 0;
                foreach (string element in allWords)
                {
                    if (temp == element)
                    {
                        count++;
                    }
                }
                Console.WriteLine("{0} times", count);
            }
        }
    }
}
