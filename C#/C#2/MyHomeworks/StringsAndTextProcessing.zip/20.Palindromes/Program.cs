﻿// Write a program that extracts from a given text all palindromes, e.g. ABBA, lamal, exe. 
namespace _20.Palindromes
{
    using System;
    using System.Text;
    class Program
    {
        static string[] separator = new string[] { ",", " ", ";", ":", "!", "?", "@", "*", "/", "\\" };
        static void Main(string[] args)
        {
            Console.Write("Enter text: ");
            string input = Console.ReadLine();
            string[] inputAsStr = input.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            IsPalindrome(inputAsStr);
        }
        static void IsPalindrome(string[] inputAsStr)
        {
            bool isPalindrome = true;
            StringBuilder result = new StringBuilder();
            foreach (string item in inputAsStr)
            {
                for (int left = 0, right = item.Length - 1; left < item.Length / 2; left++, right--)
                {
                    if (item[left] == item[right])
                        isPalindrome = true;
                    else
                    {
                        isPalindrome = false;
                        break;
                    }
                }
                if (isPalindrome == true)
                    result.AppendLine(item);
            }
            Console.WriteLine(result.ToString());
        }
    }
}
