﻿/* Write a program that finds how many times a sub-string is contained in a given text (perform case insensitive search).
Example:

The target sub-string is |in|

The text is as follows: We are liv|in|g |in| an yellow submar|in|e. We don't have anyth|in|g else. |in|side the submar|in|e is very tight. So we are dr|in|k|in|g all the day. We will move out of it |in| 5 days.

The result is: 9 */
namespace _04.Sub_StringInText
{
    using System;
    class CountingSubstrings
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a text: ");
            string input = Console.ReadLine();
            Console.Write("Enter what you want to find: ");
            string searching = Console.ReadLine();
            Counting(input, searching);
        }
        static void Counting(string input, string searching)
        {
            int counter = 0, temp = 0, position = 0;
            while (true)
            {
                temp = input.IndexOf(searching, position);
                if (temp >= 0)
                {
                    counter++;
                    position = temp + 1;
                }
                else if (temp < 0)
                    break;
            }
            Console.WriteLine("The result is: " + counter);
        }
    }
}
