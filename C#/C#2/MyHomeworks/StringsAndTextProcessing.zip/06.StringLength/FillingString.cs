﻿/* Write a program that reads from the console a string of maximum 20 characters. If the length of the string is less than 20, the rest of the characters should be filled with *.
Print the result string into the console. */
namespace _06.StringLength
{
    using System;
    class FillingString
    {
        static void Main(string[] args)
        {
            // wondering if it must be .Trim() to remove empty entries..well i did it without
            Console.Write("Enter a string: ");
            string input = Console.ReadLine();
            if (input.Length<20)
                Console.WriteLine(FillingWithStar(input));
            else
                Console.WriteLine("No change in string! It is bigger than 20 char!");
        }
        static string FillingWithStar(string input)
        {
            char[] temp = input.ToCharArray();
            int i = 0;
            while (input.Length<20)
            {
                input = input.Insert(temp.Length + i, "*");
                i++;
            }
            return input;
        }
    }
}
