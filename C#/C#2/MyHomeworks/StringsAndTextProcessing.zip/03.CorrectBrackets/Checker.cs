﻿/* Write a program to check if in a given expression the brackets are put correctly.
Example of correct expression: ((a+b)/5-d). Example of incorrect expression: )(a+b)). */
namespace _03.CorrectBrackets
{
    using System;
    class Checker
    {
        static void Main(string[] args)
        {
            Console.Write("Enter an expression: ");
            string input = Console.ReadLine();
            Result(input);
        }
        static void Result(string input)
        {
            int counter = 0;
            foreach (char symbol in input)
            {
                if (symbol == '(')
                    counter++;
                else if (symbol == ')')
                    counter--;
            }
            Console.WriteLine("The given expression is {0}!", counter==0 ? "VALID" : "INVALID");
        }
    }
}
