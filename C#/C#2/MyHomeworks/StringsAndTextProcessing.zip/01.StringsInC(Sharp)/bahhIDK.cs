﻿/* Describe the strings in C#.
What is typical for the string data type?
Describe the most important methods of the String class. */
namespace _01.StringsInC_Sharp_
{
    using System;
    class bahhIDK
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Strings contain many characters formed as text,\nmainly used method is .ToString() which is available to every single object");
        }
    }
}
