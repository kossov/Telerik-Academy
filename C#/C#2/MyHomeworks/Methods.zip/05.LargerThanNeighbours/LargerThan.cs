﻿/* Write a method that checks if the element at given position in given array of integers is larger than its two neighbours (when such exist). */

namespace _05.LargerThanNeighbours
{
    using System;

    class LargerThan
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the size of the array: ");
            int sizeOfArray = int.Parse(Console.ReadLine());
            int[] array = new int[sizeOfArray];
            for (int i = 0; i < sizeOfArray; i++)
            {
                Console.Write("Enter [{0}] element: ", i);
                array[i] = int.Parse(Console.ReadLine());
            }
            Console.Write("Enter the position of the element you want to check: ");
            int position = int.Parse(Console.ReadLine());
            if (position>sizeOfArray-1 || position<0)
            {
                Console.WriteLine("Wrong Input");
                Console.WriteLine("That position does not exist!");
                return;
            }
            Console.WriteLine("The element at position [{0}] is: {1}",position,array[position]);
            CheckPosition(array, position, sizeOfArray);
        }
        static void CheckPosition(int[] array, int position, int sizeOfArray)
        {
            if (position < 1 || position >= sizeOfArray - 1)
            {
                Console.WriteLine("There are no two neighbours near that position!");
                return;
            }
            Console.WriteLine("The two neighbours at position [{0}] are: {1} and {2}"
                ,position
                ,array[position-1]
                ,array[position+1]);
            Console.WriteLine("Larger than its neighbours: "
                +(array[position]>array[position-1]&&array[position]>array[position+1] ? "True :)" : "False :("));
        }
    }
}
