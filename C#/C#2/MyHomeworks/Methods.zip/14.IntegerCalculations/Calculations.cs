﻿/* Write methods to calculate minimum, maximum, average, sum and product of given set of integer numbers.
Use variable number of arguments. */

namespace _14.IntegerCalculations
{
    using System;

    class Calculations
    {
        static void Main(string[] args)
        {
            Console.Write("Enter how many numbers you want to have: ");
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write("Enter {0} number: ",i+1);
                arr[i] = int.Parse(Console.ReadLine());
            }
            Minimum(arr);
            Maximum(arr);
            Average(arr);
            Sum(arr);
            Product(arr);
        }
        static void Minimum(int[] arr)
        {
            int min = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                if (min>arr[i])
                    min = arr[i];
            }
            Console.WriteLine("The minimum is: "+min);
        }
        static void Maximum(int[] arr)
        {
            int max = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                if (max<arr[i])
                    max = arr[i];
            }
            Console.WriteLine("The maximum is: " + max);
        }
        static void Average(int[] arr)
        {
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
                sum += arr[i];
            Console.WriteLine("The average is: {0}",sum/arr.Length);
        }
        static void Sum(int[] arr)
        {
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
                sum += arr[i];
            Console.WriteLine("The sum is: "+sum);
        }
        static void Product(int[] arr)
        {
            int product = 1;
            for (int i = 0; i < arr.Length; i++)
                product *= arr[i];
            Console.WriteLine("The product is: "+product);
        }
    }
}
