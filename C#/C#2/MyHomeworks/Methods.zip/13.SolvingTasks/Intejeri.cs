﻿/* Write a program that can solve these tasks:
Reverses the digits of a number
Calculates the average of a sequence of integers
Solves a linear equation a * x + b = 0
Create appropriate methods.
Provide a simple text-based menu for the user to choose which task to solve.
Validate the input data:
The decimal number should be non-negative
The sequence should not be empty
a should not be equal to 0 */

namespace _13.SolveTasks
{
    using System;
    using System.Text;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(@"1 Reverse the digits of a number
2 Calculate the average of a sequence of integers
3 Solve a linear equation a * x + b = 0");
            Console.Write("Make your choice: ");
            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1: Reverse(); break;
                case 2: Average(); break;
                case 3: LinearEquation(); break;
                default:
                    break;
            }
        }
        static void Reverse()
        {
            string number = string.Empty;

            do
            {
                Console.Write("Enter a positive number: ");
                number = Console.ReadLine();
            } while (number[0] == '-');
            StringBuilder result = new StringBuilder();
            for (int i = number.Length - 1; i >= 0; i--)
            {
                result.Append(number[i]);
            }
            Console.WriteLine(result); // if needed as a double number -> Convert.ToDouble(result)
        }
        static void Average()
        {
            int n = 0;
            do
            {
                Console.Write("Enter how many integers you want to have: ");
                n = int.Parse(Console.ReadLine());
            } while (n <= 0);

            int[] numbers = new int[n];
            int sum = 0;
            for (int i = 0; i < n; i++)
            {
                Console.Write("Enter the [{0}] number: ", i + 1);
                numbers[i] = int.Parse(Console.ReadLine());
                sum += numbers[i];
                if (i == n - 1)
                    Console.WriteLine("The average is: {0}", sum / n);
            }
        }
        static void LinearEquation()
        {
            int a = 0;
            do
            {
                Console.Write("Enter a!=0: ");
                a = int.Parse(Console.ReadLine());
            } while (a == 0);
            Console.Write("Enter b: ");
            int b = int.Parse(Console.ReadLine());
            if (b < 0)
            {
                b = b * -1;
                Console.WriteLine("x={0}", b / a);
            }
            else
            {
                b = b * -1;
                Console.WriteLine("x={0}", b / a);
            }
        }
    }
}
