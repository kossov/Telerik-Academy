﻿/* Write a method GetMax() with two parameters that returns the larger of two integers.
Write a program that reads 3 integers from the console and prints the largest of them using the method GetMax(). */

namespace _02.GetLargestNumber
{
    using System;

    class LargestNum
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a: ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Enter b: ");
            int b = int.Parse(Console.ReadLine());

            Console.Write("Enter c: ");
            int c = int.Parse(Console.ReadLine());

            int bigger = GetMax(a,b);
            Console.WriteLine("The biggest number is: {0}", bigger>c ? bigger : c);

        }
        static int GetMax(int a, int b)
        {
            if (a>b)
            {
                return a;
            }
            else
            {
                return b;
            }
        }
    }
}
