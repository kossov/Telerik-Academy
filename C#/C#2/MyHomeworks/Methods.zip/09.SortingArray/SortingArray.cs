﻿/* Write a method that return the maximal element in a portion of array of integers starting at given index.
Using it write another method that sorts an array in ascending / descending order. */

namespace _09.SortingArray
{
    using System;

    class SortingArray
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the size of the array: ");
            int sizeOfArray = int.Parse(Console.ReadLine());
            int[] array = new int[sizeOfArray];
            for (int i = 0; i < sizeOfArray; i++)
            {
                Console.Write("Enter [{0}] element: ", i);
                array[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine(new string('~', 30));
            Console.Write("Enter the position after which you want to search for maximal element: ");
            int position = int.Parse(Console.ReadLine());
            MaximalElement(array, position);
            SortingAnArray(array);
        }
        static void MaximalElement(int[] array, int position)
        {
            int maxElement = 0;
            for (int i = position+1; i < array.Length; i++)
            {
                if (maxElement < array[i])
                    maxElement = array[i];
            }
            Console.WriteLine("The max element after position {0} is: {1}",position,maxElement);
            Console.WriteLine(new string('~', 30));
        }
        static void SortingAnArray(int[] array)
        {
            Console.WriteLine("How do you want to sort the array?");
            Console.Write("1 for ascending / 2 for descending order\nMake your choice: ");
            int order = int.Parse(Console.ReadLine());
            if (order == 1)
            {
                int[] ascendingArray = new int[array.Length];
                int maxElement = 0;
                for (int i = 0; i < array.Length; i++)
                {
                    if (maxElement < array[i])
                        maxElement = array[i];
                    if (i == array.Length - 1)
                        ascendingArray[array.Length-1] = maxElement;
                }
                Console.WriteLine("Your array looked like: "+string.Join(", ", array));
                maxElement--;
                int counter = array.Length-2;
                int tempMaxElement = maxElement;
                for (int j = 0; j < maxElement; j++)
                {
                    for (int i = 0; i < array.Length; i++)
                    {
                        if (tempMaxElement == array[i])
                        {
                            ascendingArray[counter] = array[i];
                            counter--;
                        }
                    }
                    tempMaxElement--;
                }
                Console.WriteLine("Now when you sorted it ascending it looks like: "+string.Join(", ", ascendingArray));
            }
            else if (order == 2)
            {
                int[] ascendingArray = new int[array.Length];
                int maxElement = 0;
                for (int i = 0; i < array.Length; i++)
                {
                    if (maxElement < array[i])
                        maxElement = array[i];
                    if (i == array.Length - 1)
                        ascendingArray[0] = maxElement;
                }
                Console.WriteLine("Your array looked like: " + string.Join(", ", array));
                maxElement--;
                int counter = 1;
                int tempMaxElement = maxElement;
                for (int j = 0; j < maxElement; j++)
                {
                    for (int i = 0; i < array.Length; i++)
                    {
                        if (tempMaxElement == array[i])
                        {
                            ascendingArray[counter] = array[i];
                            counter++;
                        }
                    }
                    tempMaxElement--;
                }
                Console.WriteLine("Now when you sorted it decending it looks like: " + string.Join(", ", ascendingArray));
            }
            else
                Console.WriteLine("Wrong Order input!");
        }
    }
}
