﻿/* Write a method that adds two positive integer numbers represented as arrays of digits (each array element arr[i] contains a digit; the last digit is kept in arr[0]).
Each of the numbers that will be added could have up to 10 000 digits. */

namespace _08.NumberAsArray
{
    using System;
    class NumberAsArray
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the first Number: ");
            string first = Console.ReadLine();
            Console.Write("Enter the second Number: ");
            string second = Console.ReadLine();
            int result = AddingNumbers(first, second);
            Console.WriteLine(result);
        }
        static int AddingNumbers(string first, string second)
        {
            int result = 0;
            if (first.Length >= second.Length)
            {
                int[] firstNumber = new int[first.Length];
                int[] secondNumber = new int[first.Length];
                for (int i = first.Length-1; i >= 0; i--)
                {
                    firstNumber[i] = first[i] - '0';
                    secondNumber[i] = second[i] - '0';
                    result += firstNumber[i] + secondNumber[i];
                }

            }
            else if (first.Length < second.Length)
            {
                int[] firstNumber = new int[second.Length];
                int[] secondNumber = new int[second.Length];
                for (int i = second.Length; i > 0; i--)
                {
                    firstNumber[i] = first[i] - '0';
                    secondNumber[i] = second[i] - '0';
                    result += firstNumber[i] + secondNumber[i];
                }
            }
            return result;
        }
    }
}
