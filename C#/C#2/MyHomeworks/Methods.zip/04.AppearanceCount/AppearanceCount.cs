﻿/* Write a method that counts how many times given number appears in given array.
Write a test program to check if the method is workings correctly. */

namespace _04.AppearanceCount
{
    using System;

    class AppearanceCount
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the size of the array: ");
            int sizeOfArray = int.Parse(Console.ReadLine());
            Console.Write("Enter the number: ");
            int givenNumber = int.Parse(Console.ReadLine());
            int[] array = new int[sizeOfArray];

            Console.WriteLine(new string('~',30));
            TestProgram(array, sizeOfArray, givenNumber);
            int counter = CountingMethod(array, givenNumber); 
            Console.WriteLine("The given number {0} appears in the array {1} {2}.", givenNumber, counter
                , counter > 1 ? "times" : "time");
            Console.WriteLine(new string('~',30));

            Console.WriteLine("Now enter your numbers!");
            counter = 0;
            Array.Clear(array, 0, sizeOfArray);
            for (int i = 0; i < sizeOfArray; i++)
            {
                Console.Write("Enter [{0}] element: ",i);
                array[i] = int.Parse(Console.ReadLine());
            }
            counter = CountingMethod(array, givenNumber);
            Console.WriteLine("The given number {0} appears in the array {1} {2}.", givenNumber, counter, counter>1 ? "times" : "time");

        }
        static int[] TestProgram(int[] array, int n, int num)
        {
            Random number = new Random();
            Console.WriteLine("The random array looks like:");
            for (int i = 0; i < n; i++)
            {
                array[i] = number.Next(num+1);
            }
            Console.WriteLine(string.Join(", ", array));
            return array;
        }
        static int CountingMethod(int[] array, int givenNumber)
        {
            int count = 0;
            foreach (int element in array)
            {
                if (element == givenNumber)
                    count++;
            }
            return count;
        }
    }
}
