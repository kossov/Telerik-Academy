﻿/* Write a method that returns the index of the first element in array that is larger than its neighbours, or -1, if there’s no such element.
Use the method from the previous exercise. */

namespace _06.FirstLargerThanNeighbours
{
    using System;

    class FirstLargerThan
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the size of the array: ");
            int sizeOfArray = int.Parse(Console.ReadLine());
            int[] array = new int[sizeOfArray];
            for (int i = 0; i < sizeOfArray; i++)
            {
                Console.Write("Enter [{0}] element: ", i);
                array[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine(FirstLarger(array));
        }
        static int FirstLarger(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (i - 1 == -1 || i + 1 == array.Length)
                    continue;
                else
                {
                    if (array[i]>array[i-1] && array[i]>array[i+1])
                        return array[i];
                }
            }
            return -1;
        }
    }
}
