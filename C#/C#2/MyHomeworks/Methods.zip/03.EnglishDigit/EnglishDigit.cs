﻿/* Write a method that returns the last digit of given integer as an English word.
Examples:

input	output
512	two
1024	four
12309	nine */

namespace _03.EnglishDigit
{
    using System;

    class EnglishDigit
    {
        static void Main(string[] args)
        {
            Console.Write("Enter digit: ");
            int digit = int.Parse(Console.ReadLine());
            Word(digit);
        }
        static void Word(int digit)
        {
            int lastDigit = digit % 10;
            switch (lastDigit)
            {
                case 1: Console.WriteLine("One"); break;
                case 2: Console.WriteLine("Two"); break;
                case 3: Console.WriteLine("Three"); break;
                case 4: Console.WriteLine("Four"); break;
                case 5: Console.WriteLine("Five"); break;
                case 6: Console.WriteLine("Six"); break;
                case 7: Console.WriteLine("Seven"); break;
                case 8: Console.WriteLine("Eight"); break;
                case 9: Console.WriteLine("Nine"); break;
                case 0: Console.WriteLine("Zero"); break;

                default: Console.WriteLine("Wrong Input!");
                    break;
            }
        }
    }
}
