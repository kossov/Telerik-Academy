﻿/* Write a method that asks the user for his name and prints “Hello, <name>”
Write a program to test this method.
Example:

input	output
Peter	Hello, Peter! */

namespace _01.SayHello
{
    using System;

    class Hello
    {
        static void Main(string[] args)
        {
            Console.Write("Your name: ");
            string name = Console.ReadLine();
            Printing(name);
        }
        static void Printing(string hjhhj)
        {
            Console.WriteLine("Hello, {0}!",hjhhj);
        }
    }
}
