﻿/* Write a method that reverses the digits of given decimal number.
Example:

input	output
256	    652
123.45	54.321 */

namespace _07.ReverseNumber
{
    using System;
    using System.Text;

    class ReverseThatShiet
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a decimal number: ");
            double number = double.Parse(Console.ReadLine());
            string numberAsString = number.ToString();
            Reverse(numberAsString);
        }
        static void Reverse(string number)
        {
            StringBuilder result = new StringBuilder();
            for (int i = number.ToString().Length-1; i >= 0 ; i--)
            {
                result.Append(number[i]);
            }
            Console.WriteLine(result); // if needed as a double number -> Convert.ToDouble(result)
        }
    }
}
