﻿//Write a program to convert decimal numbers to their hexadecimal representation.

namespace _03.DecimalToHexadecimal
{
    using System;
    class Decimal2Hexa
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a decimal number: ");
            int input = int.Parse(Console.ReadLine());
            string result = ToHexa(input);
            Console.WriteLine(result);
        }
        static string ToHexa(int input)
        {
            int tempNumber = 0;
            tempNumber = tempNumber / (int)Math.Pow(10, input.ToString().Length - 2);
            int tempSubstractionDigit = 0;
            int tempResult = 0;
            string finalResultReversed = string.Empty;
            while (input >= 16)
            {
                for (int i = 1; i <= input.ToString().Length; i++)
                {
                    tempNumber += (input / (int)Math.Pow(10, input.ToString().Length - i))%10;
                    if (tempNumber < 16 && i==input.ToString().Length)
                    {
                        tempResult = tempNumber;
                        break;
                    }
                    else if (tempNumber < 16)
                    {
                        tempNumber *= 10;
                        continue;
                    }
                    while (tempSubstractionDigit < tempNumber)
                        tempSubstractionDigit += 16;
                    if (tempSubstractionDigit > tempNumber)
                        tempSubstractionDigit -= 16;
                    tempNumber = tempNumber - tempSubstractionDigit;
                    if (i < input.ToString().Length)
                    {
                        tempNumber *= 10;
                        tempSubstractionDigit = 0;
                    }
                    else
                    {
                        tempSubstractionDigit = 0;
                        tempResult = tempNumber;
                    }
                }
                finalResultReversed = FindingResultInHexadecimalFormat(tempResult, finalResultReversed);
                tempNumber = 0;
                input = input / 16;
                if (input/10==0)
                    finalResultReversed = finalResultReversed + input; // if it is last digit
            }
            char[] finalResult = finalResultReversed.ToCharArray();
            Array.Reverse(finalResult);
            return new string(finalResult);
        }

        private static string FindingResultInHexadecimalFormat(int tempResult, string finalResultReversed)
        {
            switch (tempResult)
            {
                case 1: finalResultReversed = finalResultReversed + "1"; break;
                case 2: finalResultReversed = finalResultReversed + "2"; break;
                case 3: finalResultReversed = finalResultReversed + "3"; break;
                case 4: finalResultReversed = finalResultReversed + "4"; break;
                case 5: finalResultReversed = finalResultReversed + "5"; break;
                case 6: finalResultReversed = finalResultReversed + "6"; break;
                case 7: finalResultReversed = finalResultReversed + "7"; break;
                case 8: finalResultReversed = finalResultReversed + "8"; break;
                case 9: finalResultReversed = finalResultReversed + "9"; break;
                case 10: finalResultReversed = finalResultReversed + "A"; break;
                case 11: finalResultReversed = finalResultReversed + "B"; break;
                case 12: finalResultReversed = finalResultReversed + "C"; break;
                case 13: finalResultReversed = finalResultReversed + "D"; break;
                case 14: finalResultReversed = finalResultReversed + "E"; break;
                case 15: finalResultReversed = finalResultReversed + "F"; break;
                default:
                    break;
            }
            return finalResultReversed;
        }
    }
}
