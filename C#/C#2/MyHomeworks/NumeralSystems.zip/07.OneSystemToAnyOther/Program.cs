﻿// Write a program to convert from any numeral system of given base s to any other numeral system of base d (2 ≤ s, d ≤ 16).
namespace _07.OneSystemToAnyOther
{
    using System;
    using System.Text;
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number: ");
            string input = Console.ReadLine();
            Console.Write("Enter the in what numeral system it is(its base): ");
            int inputNumeralSys = int.Parse(Console.ReadLine());
            Console.Write("Choose the numeral system in which you want to convert(d<=16): ");
            int desiredBase = int.Parse(Console.ReadLine());
            int numberInDecimal = ConvertingToDecimal(input, inputNumeralSys);
            string result = ConvertingToBase(numberInDecimal, desiredBase);
            Console.WriteLine("The number {0} entered in {1} is now: {2} in {3}",input,inputNumeralSys,result,desiredBase);
        }
        static int ConvertingToDecimal(string input, int numeralSys)
        {
            int result = 0, count = 0;
            for (int i = input.Length - 1; i >= 0; i--)
            {
                result += (input[i] - '0') * (int)Math.Pow(numeralSys, count);
                count++;
            }
            return result;
        }
        static string ConvertingToBase(int result, int desiredBase)
        {
            StringBuilder finalResult = new StringBuilder();
            while (result>0)
            {
                finalResult.Insert(0,result % desiredBase);
                result /= desiredBase;
            }
            return finalResult.ToString();
        }
    }
}