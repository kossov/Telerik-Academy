﻿// Write a program to convert hexadecimal numbers to their decimal representation.
namespace _04.HexadecimalToDecimal
{
    using System;
    class Hexa2Decimal
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a hexadecimal number: ");
            string input = Console.ReadLine();
            int result = ToDecimal(input);
            Console.WriteLine("The number in decimal form is: "+result);
        }
        static int ToDecimal(string input)
        {
            int result = 0;
            int number = 0;
            for (int i = 0; i < input.Length; i++)
            {
                number = FromCharFindingInteger(input[i]);
                result += number * (int)Math.Pow(16, input.Length - 1 - i);
            }
            return result;
        }
        static int FromCharFindingInteger(char input)
        {
            switch (input)
            {
                case '1': return 1;
                case '2': return 2;
                case '3': return 3;
                case '4': return 4;
                case '5': return 5;
                case '6': return 6;
                case '7': return 7;
                case '8': return 8;
                case '9': return 9;
                case 'A': return 10;
                case 'B': return 11;
                case 'C': return 12;
                case 'D': return 13;
                case 'E': return 14;
                case 'F': return 15;
                default:
                    break;
            }
            return 0;
        }
    }
}
