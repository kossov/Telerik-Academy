﻿// Write a program to convert binary numbers to hexadecimal numbers (directly).
namespace _06.BinaryToHexadecimal
{
    using System;
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter binary number: ");
            string input = Console.ReadLine();
            string inputToHexa = inputToHexa = Convert.ToString(Convert.ToInt32(input.ToString(), 2), 16);
            Console.WriteLine("The number in hexadecimal looks like: "+inputToHexa.ToUpper());
        }
    }
}
