﻿// Write a program that shows the binary representation of given 16-bit signed integer number (the C# type short).
namespace _08.BinaryShort
{
    using System;
    using System.Text;
    class BS
    {
        static void Main(string[] args)
        {
            Console.Write("Enter 16-bit signed integer number: ");
            short input = short.Parse(Console.ReadLine());
            InBinary(input);
        }
        static void InBinary(short input)
        {
            StringBuilder result = new StringBuilder();
            if (input < 0)
            {
                input = (short)(Math.Abs(input)-1);
                while (input > 0)
                {
                    result.Insert(0,(short)(input % 2));
                    input = (short)(input / 2);
                }
                string tempCharChanging = result.ToString();
                result.Clear();
                foreach (char symbol in tempCharChanging)
                {
                    result.Append(symbol == '1' ? 0 : 1);
                }
                result.Replace(result.ToString(), result.ToString().PadLeft(16, '1'));
                Console.WriteLine("The number in binary: " + result.ToString());
            }
            else
            {
                while (input > 0)
                {
                    result = result.Insert(0, Convert.ToString(input % 2));
                    input = (short)(input / 2);
                }
                result.Replace(result.ToString(),result.ToString().PadLeft(16,'0'));
                Console.WriteLine("The number in binary: " + result.ToString());
            }
        }
    }
}
