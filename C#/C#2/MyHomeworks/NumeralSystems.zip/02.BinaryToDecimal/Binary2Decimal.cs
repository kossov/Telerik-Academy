﻿//Write a program to convert binary numbers to their decimal representation.
namespace _02.BinaryToDecimal
{
    using System;
    class Binary2Decimal
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a binary number: ");
            int input = int.Parse(Console.ReadLine());
            ToDecimal(input);
        }
        static void ToDecimal(int number)
        {
            int digit = 0;
            int result = 0;
            int numberLength = number.ToString().Length;
            for (int i = 0; i < numberLength; i++)
            {
                digit = number % 10;
                number /= 10;
                if (digit==1)
                    result += (int)Math.Pow(2, i);
            }
            Console.WriteLine("The number in decimal is: "+result);
        }
    }
}
