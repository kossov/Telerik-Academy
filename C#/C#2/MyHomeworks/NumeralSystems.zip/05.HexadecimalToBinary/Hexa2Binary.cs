﻿//Write a program to convert hexadecimal numbers to binary numbers (directly)
namespace _05.HexadecimalToBinary
{
    using System;
    using System.Linq;
    class Hexa2Binary
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a hexadecimal number: ");
            string input = Console.ReadLine();
            string binarystring = String.Join(String.Empty, input.Select(c => Convert.ToString(Convert.ToInt32(c.ToString(), 16), 2).PadLeft(4, '0')));
            Console.WriteLine("The number in binary looks like: "+binarystring);
        }

    }
}
