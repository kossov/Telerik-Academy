﻿// Write a program to convert decimal numbers to their binary representation.

namespace _01.DecimalToBinary
{
    using System;
    using System.Text;
    class Decimal2Binary
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a decimal number: ");
            int input = int.Parse(Console.ReadLine());
            string result = InputToBinary(input);
            Console.WriteLine("The number in binary is: "+result);
        }
        static string InputToBinary(int input)
        {
            StringBuilder resultReversed = new StringBuilder();
            int remainder = 0;
            while (input >= 1)
            {
                remainder = input % 2;
                resultReversed.Append(remainder.ToString());
                input /= 2;
            }
            char [] result = resultReversed.ToString().ToCharArray();
            Array.Reverse(result);
            return new string(result);
        }
    }
}
