﻿// Write a program that fills and prints a matrix of size (n, n) as shown below:

using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter the size of the matrix: ");
        int size = int.Parse(Console.ReadLine());
        int[,] myMatrix = new int[size, size];
        int counter = 1;
        Console.WriteLine("Choose a style for your matrix.");
        Console.Write(@"A)          B)          C)          D)
1 5 9  13   1 8 9  16   7 11 14 16  1 12 11 10
2 6 10 14   2 7 10 15   4 8  12 15  2 13 16 9
3 7 11 15   3 6 11 14   2 5  9  13  3 14 15 8
4 8 12 16   4 5 12 13   1 3  6  10  4 5  6  7");
        Console.WriteLine();
        char style = char.Parse(Console.ReadLine());
        style = Convert.ToChar(style.ToString().ToUpper());
        switch (style)
        {
            case 'A': counter = StyleA(size, myMatrix, counter); break;
            case 'B': counter = StyleB(size, myMatrix, counter); break;
            case 'C': counter = StyleC(size, myMatrix, counter); break;
            case 'D': StyleD(size, myMatrix); break;
            default:
                break;
        }
        for (int row = 0; row < size; row++)
        {
            for (int columns = 0; columns < size; columns++)
            {
                Console.Write("{0,3}", myMatrix[row, columns]);
            }
            Console.WriteLine();
        }
    }
    private static void StyleD(int size, int[,] myMatrix)
    {
        int rows = 0, cols = 0;
        string direction = "down";
        for (int i = 1; i <= size * size; i++)
        {
            if (direction == "right" && (cols > (size - 1) || myMatrix[rows, cols] != 0))
            {
                direction = "up";
                rows--;
                cols--;
            }
            if (direction == "down" && (rows > (size - 1) || myMatrix[rows, cols] != 0))
            {
                direction = "right";
                cols++;
                rows--;
            }
            if (direction == "left" && (cols < 0 || myMatrix[rows, cols] != 0))
            {
                direction = "down";
                rows++;
                cols++;
            }
            if (direction == "up" && (rows < 0 || myMatrix[rows, cols] != 0))
            {
                direction = "left";
                cols--;
                rows++;
            }
            myMatrix[rows, cols] = i;
            if (direction == "right")
            {
                cols++;
            }
            if (direction == "down")
            {
                rows++;
            }
            if (direction == "left")
            {
                cols--;
            }
            if (direction == "up")
            {
                rows--;
            }
        }
    }

    private static int StyleC(int size, int[,] matrix, int counter)
    {
        int i = 0;

        for (int row = size - 1; row >= 0; row--)
        {
            i = row;
            for (int col = 0; col < size - row; col++)
            {
                matrix[i++, col] = counter++;
            }
        }
        counter = size * size;
        for (int row = 0; row < size - 1; row++)
        {
            i = row;
            for (int col = size - 1; i >= 0; col--)
            {
                matrix[i--, col] = counter--;
            }
        }
        return counter;
    }


    private static int StyleB(int size, int[,] matrix, int counter)
    {
        bool directionDown = true;
        int upRows = size - 1;
        for (int col = 0; col < size; col++)
        {
            for (int row = 0; row < size; row++)
            {
                if (directionDown == true)
                {
                    matrix[row, col] = counter;
                    counter++;
                }
                else
                {
                    matrix[upRows, col] = counter;
                    counter++;
                    upRows--;
                }
            }
            upRows = size - 1;
            if (col%2==0)
            {
                directionDown = false;
            }
            else
            {
                directionDown = true;
            }
        }
        return counter;
    }

    private static int StyleA(int size, int[,] matrix, int counter)
    {
        for (int col = 0; col < size; col++)
        {
            for (int row = 0; row < size; row++)
            {
                matrix[row, col] = counter;
                counter++;
            }
        }
        return counter;
    }
}
