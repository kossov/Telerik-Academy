﻿/* We are given a matrix of strings of size N x M. Sequences in the matrix we define as sets of several neighbour elements located on the same line, column or diagonal.
Write a program that finds the longest sequence of equal strings in the matrix. */

using System;

class Program
{//mnoo ganda zadacha eii ubih sa 2 pati
    static void Main(string[] args)
    {
        Console.WriteLine("{0}Enter the size of the matrix[N,M]{0}", new string('~', 15));
        Console.Write("Enter N: ");
        int n = int.Parse(Console.ReadLine());
        Console.Write("Enter M: ");
        int m = int.Parse(Console.ReadLine());
        string[,] matrix = new string[n, m];
        // filling the matrix
        FillingInMatrix(matrix);

        // printing the matrix
        PrintingGivenMatrix(matrix);

        string sequenceY = string.Empty; int countY = 1;
        string sequenceX = string.Empty; int countX = 1;
        string sequenceLeftDiagonal = string.Empty; int countLeftDiagonal = 1;
        string sequenceRightDiagonal = string.Empty; int countRightDiagonal = 1;

        SearchByRightDiagonal(matrix, ref sequenceRightDiagonal, ref countRightDiagonal);

        SearchByLeftDiagonal(matrix, ref sequenceLeftDiagonal, ref countLeftDiagonal);

        SearchByRowY(matrix, ref sequenceY, ref countY);

        SearchByColX(matrix, ref sequenceX, ref countX);

        PrintingResult(sequenceY, countY, sequenceX, countX, sequenceLeftDiagonal, countLeftDiagonal, sequenceRightDiagonal, countRightDiagonal);

    }

    private static void FillingInMatrix(string[,] matrix)
    {
        Console.WriteLine();
        for (int row = 0; row < matrix.GetLength(0); row++)
        {
            for (int col = 0; col < matrix.GetLength(1); col++)
            {
                Console.Write("Enter Matrix[{0},{1}]: ", row, col);
                matrix[row, col] = Console.ReadLine();
            }
        }
    }

    private static void PrintingGivenMatrix(string[,] matrix)
    {
        Console.WriteLine("Your matrix looks like: ");
        for (int row = 0; row < matrix.GetLength(0); row++)
        {
            for (int col = 0; col < matrix.GetLength(1); col++)
            {
                Console.Write("{0,5}", matrix[row, col]);
            }
            Console.WriteLine();
        }
        Console.WriteLine();
    }

    private static void PrintingResult(string sequenceY, int countY, string sequenceX, int countX, string sequenceLeftDiagonal, int countLeftDiagonal, string sequenceRightDiagonal, int countRightDiagonal)
    {
        if (countY > countX && countY > countLeftDiagonal && countY > countRightDiagonal)
            Console.WriteLine("Best sequence: {0} Found: {1} times!", sequenceY, countY);
        else if (countX > countY && countX > countLeftDiagonal && countX > countRightDiagonal)
            Console.WriteLine("Best sequence: {0} Found: {1} times!", sequenceX, countX);
        else if (countLeftDiagonal > countX && countLeftDiagonal > countY && countLeftDiagonal > countRightDiagonal)
            Console.WriteLine("Best sequence: {0} Found: {1} times!", sequenceLeftDiagonal, countLeftDiagonal);
        else if (countRightDiagonal > countX && countRightDiagonal > countY && countRightDiagonal > countLeftDiagonal)
            Console.WriteLine("Best sequence: {0} Found: {1} times!", sequenceRightDiagonal, countRightDiagonal);
    }

    private static void SearchByRightDiagonal(string[,] matrix, ref string sequenceRightDiagonal, ref int countRightDiagonal)
    {
        int tempCount = 1;
        for (int row = 0; row < matrix.GetLength(0); row++)
        {
            for (int col = matrix.GetLength(1) - 1; col > 0; col--)
            {
                if ((row + 1 > matrix.GetLength(0) - 1) || (col - 1 < 0))
                    break;
                else if (matrix[row, col] == matrix[row + 1, col - 1])
                {
                    tempCount++;
                    int tempRow = row + 1, tempCol = col - 1;
                    do
                    {
                        if ((tempRow + 1 > matrix.GetLength(0) - 1) || (tempCol - 1 < 0))
                            break;
                        if (matrix[tempRow, tempCol] == matrix[tempRow + 1, tempCol - 1])
                        {
                            tempCount++;
                            if (tempCount >= countRightDiagonal)
                            {
                                countRightDiagonal++;
                                sequenceRightDiagonal = matrix[tempRow, tempCol];
                            }
                        }
                        tempCol++;
                        tempRow++;
                    } while (true);
                    if (tempCount >= countRightDiagonal)
                    {
                        countRightDiagonal++;
                        sequenceRightDiagonal = matrix[row, col];
                    }
                    tempCount = 1;
                }
            }
            tempCount = 1;
        }
    }

    private static void SearchByLeftDiagonal(string[,] matrix, ref string sequenceLeftDiagonal, ref int countLeftDiagonal)
    {
        int tempCount = 1;
        for (int row = 0; row < matrix.GetLength(0); row++)
        {
            for (int col = 0; col < matrix.GetLength(1); col++)
            {
                if ((row + 1 > matrix.GetLength(0) - 1) || (col + 1 > matrix.GetLength(1) - 1))
                    break;
                else if (matrix[row, col] == matrix[row + 1, col + 1])
                {
                    tempCount++;
                    int tempRow = row + 1, tempCol = col + 1;
                    do
                    {
                        if ((tempRow + 1 > matrix.GetLength(0) - 1) || (tempCol + 1 > matrix.GetLength(1) - 1))
                            break;
                        if (matrix[tempRow, tempCol] == matrix[tempRow + 1, tempCol + 1])
                        {
                            tempCount++;
                            if (tempCount >= countLeftDiagonal)
                            {
                                countLeftDiagonal++;
                                sequenceLeftDiagonal = matrix[tempRow, tempCol];
                            }
                        }
                        tempCol++;
                        tempRow++;
                    } while (true);
                    if (tempCount >= countLeftDiagonal)
                    {
                        countLeftDiagonal++;
                        sequenceLeftDiagonal = matrix[row, col];
                    }
                    tempCount = 1;
                }
            }
            tempCount = 1;
        }
    }

    private static void SearchByRowY(string[,] matrix, ref string sequenceY, ref int countY)
    {
        int tempCount = 1;
        for (int col = 0; col < matrix.GetLength(1); col++)
        {
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                if (row + 1 > matrix.GetLength(0) - 1)
                    break;
                else if (matrix[row, col] == matrix[row + 1, col])
                {
                    tempCount++;
                    if (tempCount > countY)
                    {
                        countY++;
                        sequenceY = matrix[row, col];
                    }
                }
                else
                    tempCount = 1;
            }
            tempCount = 1;
        }
    }

    private static void SearchByColX(string[,] matrix, ref string sequenceX, ref int countX)
    {
        int tempCount = 1;
        for (int row = 0; row < matrix.GetLength(0); row++)
        {
            for (int col = 0; col < matrix.GetLength(1); col++)
            {
                if (col + 1 > matrix.GetLength(1) - 1)
                    break;
                else if (matrix[row, col] == matrix[row, col + 1])
                {
                    tempCount++;
                    if (tempCount >= countX)
                    {
                        countX++;
                        sequenceX = matrix[row, col];
                    }
                }
                else
                    tempCount = 1;
            }
            tempCount = 1;
        }
    }
}