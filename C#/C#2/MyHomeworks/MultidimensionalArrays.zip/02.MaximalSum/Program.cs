﻿// Write a program that reads a rectangular matrix of size N x M and finds in it the square 3 x 3 that has maximal sum of its elements.

using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter N: ");
        int n = int.Parse(Console.ReadLine());
        Console.Write("Enter M: ");
        int m = int.Parse(Console.ReadLine());
        int[,] matrix = new int[n, m];

        FillingInTheMatrix(matrix); // Ex. 3x4 -> 1  2  3  4
                                    //            5  6  7  8
                                    //            9 10 11 12
        int sum = 0, square = 3, topLeftCol = 0, topLeftRow = 0, maxSum = 0;
        if (square > n || square > m)
        {
            Console.WriteLine("The entered size of the matrix is lower than 3x3 so we cannot find its sum!");
        }
        else
        {
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    if (topLeftCol + 3 > matrix.GetLength(1))
                    {
                        break;
                    }
                    else
                    {
                        SquareMatrix(matrix, ref sum, topLeftCol, topLeftRow, ref maxSum);
                    }
                    topLeftCol++;
                    sum = 0;
                }
                topLeftCol = 0;
                topLeftRow++;
                if (topLeftRow+3 > matrix.GetLength(0))
                    break;
            }
            Console.WriteLine(maxSum);
        }
    }

    private static void FillingInTheMatrix(int[,] matrix)
    {
        int counter = 1;
        for (int row = 0; row < matrix.GetLength(0); row++)
        {
            for (int col = 0; col < matrix.GetLength(1); col++)
            {
                matrix[row, col] = counter++;
            }
        }
    }

    private static void SquareMatrix(int[,] matrix, ref int sum, int topLeftCol, int topLeftRow, ref int maxSum)
    {
        for (int squareRow = topLeftRow; squareRow < topLeftRow + 3; squareRow++)
        {
            for (int squareCol = topLeftCol; squareCol < topLeftCol + 3; squareCol++)
            {
                sum += matrix[squareRow, squareCol];
                if (sum > maxSum)
                {
                    maxSum = sum;
                }
            }
        }
    }
}
