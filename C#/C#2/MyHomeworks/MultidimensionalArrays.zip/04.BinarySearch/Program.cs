﻿/* Write a program, that reads from the console an array of N integers and an integer K, sorts the array and using the method Array.BinSearch() finds the largest number in the array which is ≤ K. */

using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter the size of the array: ");
        int size = int.Parse(Console.ReadLine());
        Console.Write("Enter integer K: ");
        int k = int.Parse(Console.ReadLine());
        int[] arr = new int[size];
        for (int i = 0; i < size; i++)
        {
            Console.Write("Enter the [{0}] integer: ",i);
            arr[i] = int.Parse(Console.ReadLine());
        }
        Array.Sort(arr);
        int result = 0;
        for (int i = 0; i < size; i++)
        {
            if (result!=0 && result>=0)
                break;
            result = Array.BinarySearch(arr, k-i);
        }
        if (result==0)
        {
            Console.WriteLine("Not found!");
        }
        else
        {
            Console.WriteLine("K>={0}",arr[result]);
        }
    }
}