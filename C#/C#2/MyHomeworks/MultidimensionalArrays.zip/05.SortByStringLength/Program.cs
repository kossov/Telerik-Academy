﻿/* You are given an array of strings. Write a method that sorts the array by the length of its elements (the number of characters composing them). */

using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter the length of the array: ");
        int size = int.Parse(Console.ReadLine());
        string[] arr = new string[size];
        for (int i = 0; i < size; i++)
        {
            Console.Write("Enter the [{0}] element: ", i);
            arr[i] = Console.ReadLine();
        }
        List<string> result = new List<string>();
        int biggest = 0;
        biggest = FindingTheBiggestLength(size, arr, biggest);
        biggest = RearangingByLength(size, arr, result, biggest);
        Console.WriteLine();
        result.ForEach(Console.WriteLine);
    }

    private static int RearangingByLength(int size, string[] arr, List<string> result, int biggest)
    {
        for (int i = biggest; i >= 0; i--)
        {
            for (int k = 0; k < size; k++)
            {
                if (arr[k].Length == i)
                {
                    result.Add(arr[k]);
                }
            }
        }
        return biggest;
    }

    private static int FindingTheBiggestLength(int size, string[] arr, int biggest)
    {
        for (int i = 0, tempSize = 0; i < size; i++)
        {
            tempSize = arr[i].Length;
            if (tempSize > biggest)
                biggest = tempSize;
        }
        return biggest;
    }
}