﻿/* Write a program that downloads a file from Internet (e.g. Ninja image) and stores it the current directory.
Find in Google how to download files in C#.
Be sure to catch all exceptions and to free any used resources in the finally block. */
namespace _04.DownloadFile
{
    using System;
    using System.IO;
    using System.Net;
    class Program
    {
        static void Main(string[] args)
        {
            WebClient Client = new WebClient();
            Client.DownloadFile("http://telerikacademy.com/Content/Images/news-img01.png",@"..\..\MyDownloadedNinjaImage.jpg");
            Console.WriteLine("Just downloaded NinjaImage from the net!");
            FileInfo ninjaImagePath = new FileInfo(@"..\..\MyDownloadedNinjaImage.jpg");
            Console.WriteLine("It is located at: {0}",ninjaImagePath.FullName);
            Console.WriteLine(new string('~',40));
            Console.Write("Now enter other image' URL: ");
            string imageURL = Console.ReadLine();
            Console.WriteLine("Where you want to save it?\nOr use the default foldier and default name entering \"..\\..\\MyImage.jpg\"");
            Console.Write(":");
            string saveImage = Console.ReadLine();
            try
            {
                Client.DownloadFile(imageURL, saveImage);
                Console.WriteLine("Downloaded sucessful!");
                ninjaImagePath = new FileInfo(saveImage);
                Console.WriteLine("Can be found at: " + ninjaImagePath.FullName);
            }
            catch (ArgumentNullException)
            {
                Console.WriteLine("You gave me nothing :(");
            }
            catch (WebException)
            {
                Console.WriteLine("Whoa! An error occured, not my fault :(");
            }
            catch (NotSupportedException)
            {
                Console.WriteLine("Oops! The file you gave me is not supported :(");
            }
        }
    }
}
