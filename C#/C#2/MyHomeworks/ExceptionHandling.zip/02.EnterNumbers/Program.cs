﻿/* Write a method ReadNumber(int start, int end) that enters an integer number in a given range [start…end].
If an invalid number or non-number text is entered, the method should throw an exception.
Using this method write a program that enters 10 numbers: a1, a2, … a10, such that 1 < a1 < … < a10 < 100 */
namespace _02.EnterNumbers
{
    using System;
    using System.Collections.Generic;
    class Program
    {
        static void Main(string[] args)
        {
            int start = 0, end = 0;
            do
            {
                Console.Write("Enter start: ");
                start = int.Parse(Console.ReadLine());
            } while (start < 0 || start > 100);
            do
            {
                Console.Write("Enter end: ");
                end = int.Parse(Console.ReadLine());
            } while (start < 0 || start > 100 || end <= start);
            List<int> result = new List<int>();
            result.Add(ReadNumber(start, end));
            for (int i = 1; i < 9; i++)
            {
                result.Add(ReadNumber(result[i - 1], end));
            }
        }
        private static int ReadNumber(int start, int end)
        {
            try
            {
                Console.Write("Enter an integer number in ({0},{1}): ", start, end);
                int input = start;
                while (input <= start || input >= end)
                {
                    input = int.Parse(Console.ReadLine());
                    if (input > start && input < end)
                        return input;
                    else
                    {
                        Console.WriteLine("The number must be in the interval ({0},{1})!", start, end);
                        Console.Write("Enter again: ");
                    }
                }
            }
            catch (Exception exc)
            {
                Console.WriteLine(exc.Message);
            }
            return 0; // never happens
        }

    }
}
