﻿/* Write a program that enters file name along with its full file path (e.g. C:\WINDOWS\win.ini), reads its contents and prints it on the console.
Find in MSDN how to use System.IO.File.ReadAllText(…).
Be sure to catch all possible exceptions and print user-friendly error messages. */
namespace _03.ReadFileContents
{
    using System;
    using System.IO;
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the full filepath of the file\n or use the build in entering \"..\\..\\MyFile.txt\"");
            string input = Console.ReadLine();
            StreamReader reader = new StreamReader(input);
            try
            {
                FileInfo location = new FileInfo(input);
                Console.WriteLine("The full file path is:\n{0}",location.FullName);
                Console.WriteLine("\nIts contents are:");
                if (reader.ReadToEnd().Equals(""))
                {
                    throw new ArgumentNullException();
                }
                Console.WriteLine(reader.ReadToEnd());
               
            }
            catch (ArgumentNullException)
            {
                Console.WriteLine("File is emtpy!");
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Invalid argument!");
            }
            catch (DirectoryNotFoundException)
            {
                Console.WriteLine("Directory not found!");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("File not found!");
            }
            catch (Exception exc)
            {
                Console.WriteLine("Something bad happened!");
                Console.WriteLine(exc.Message);
            }
            finally
            {
                reader.Close();
            }
        }
    }
}
