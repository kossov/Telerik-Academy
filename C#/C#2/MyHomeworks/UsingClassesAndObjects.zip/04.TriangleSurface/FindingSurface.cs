﻿/* Write methods that calculate the surface of a triangle by given:
Side and an altitude to it;
Three sides;
Two sides and an angle between them;
Use System.Math. */
namespace _04.TriangleSurface
{
    using System;
    class FindingSurface
    {
        static void Main(string[] args)
        {
            Console.WriteLine(@"1 Side and an altitude to it
2 Three sides
3 Two sides and an angle between them");
            Console.Write("pick one: ");
            int choice = int.Parse(Console.ReadLine());
            Choice(choice);
        }
        static void Choice(int choice)
        {
            switch (choice)
            {
                case 1: SideAndAltitude(); break;
                case 2: ThreeSides(); break;
                case 3: TwoSidesAndAngleBetween(); break;
                default:
                    break;
            }
        }
        static void SideAndAltitude()
        {
            Console.Write("Enter the side: ");
            double side = double.Parse(Console.ReadLine());
            Console.Write("Enter the altitude H: ");
            double altitude = double.Parse(Console.ReadLine());
            Console.WriteLine("The surface area is: {0}",(double)(side*altitude/2));
        }
        static void ThreeSides()
        {
            Console.Write("Enter the first side A: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Enter the second side B: ");
            int b = int.Parse(Console.ReadLine());
            Console.Write("Enter the third side C: ");
            int c = int.Parse(Console.ReadLine());
            Console.WriteLine("The surface area equals: {0}",(a+b+c)/2);
        }
        static void TwoSidesAndAngleBetween()
        {
            Console.Write("Enter the first side A in cm: ");
            double a = double.Parse(Console.ReadLine()) / 1000;
            Console.Write("Enter the second side B in cm: ");
            double b = double.Parse(Console.ReadLine()) / 1000;
            Console.Write("Enter the angle between in degrees: ");
            double angle = (Math.PI/180)*-1*Math.Sin(double.Parse(Console.ReadLine())) * 100; // from radians to degrees
            Console.WriteLine("The surface area equals: {0}",(a * b / 2 * 1000)*angle);
        }
    }
}
