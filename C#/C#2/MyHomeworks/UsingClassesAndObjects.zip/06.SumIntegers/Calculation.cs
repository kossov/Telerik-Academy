﻿/* You are given a sequence of positive integer values written into a string, separated by spaces.
Write a function that reads these values from given string and calculates their sum.
Example:

     input	        output
"43 68 9 23 318"	 461 */
namespace _06.SumIntegers
{
    using System;
    class Calculation
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a sequence of positive integer numbers separated by space: ");
            string input = Console.ReadLine();
            Console.WriteLine("The sum of the given sequence is: "+Result(input));
        }
        static string Result(string input)
        {
            string[] allNumbersAsString = input.Split(' ');
            int sum = 0;
            for (int i = 0; i < allNumbersAsString.Length; i++)
                sum += Convert.ToInt32(allNumbersAsString[i]);
            return sum.ToString();
        }
    }
}
