﻿/* Write a method that calculates the number of workdays between today and given date, passed as parameter.
Consider that workdays are all days from Monday to Friday except a fixed list of public holidays specified preliminary as array. */
namespace _05.Workdays
{
    using System;
    using System.Collections.Generic;
    class CalculatingWorkdays
    {
        static List<DateTime> publicHolydays;

        static void Main(string[] args)
        {
            
            publicHolydays = new List<DateTime>()
            {new DateTime(2015, 3, 1),new DateTime(2015, 3, 3),new DateTime(2015, 4, 2),
            new DateTime(2015, 4, 10), new DateTime(2015, 5, 2),new DateTime(2015, 5, 12),
            new DateTime(2015, 5, 16),new DateTime(2015, 6, 13),new DateTime(2015, 6, 15)};
            DateTime today = DateTime.Today;
            Console.WriteLine("From today " + today.ToShortDateString() + " to " + new DateTime(2015,12,21).ToShortDateString() + " we have:\n" + CountDays(today, new DateTime(2015, 12, 21)));
        }
        static string CountDays(DateTime startDate, DateTime endDate)
        {
            int holydays = 0, workdays = 0, weekends = 0;
            while (startDate <= endDate)
            {
                if (publicHolydays.Contains(startDate))
                    holydays++;
                else if ((int)startDate.DayOfWeek == 0 || (int)startDate.DayOfWeek == 6)
                    weekends++;
                else
                    workdays++;
                startDate = startDate.AddDays(1);
            }
            return string.Format("Holydays: {0}\nWorkdays: {1}\nWeekends: {2}",holydays,workdays,weekends);
        }
    }
}
