﻿/* Write a program that reads a year from the console and checks whether it is a leap one.
Use System.DateTime. */
namespace _01.LeapYear
{
    using System;
    class IsItLeap
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a year: ");
            int year = int.Parse(Console.ReadLine());
            bool result = DateTime.IsLeapYear(year);
            Console.WriteLine("The entered year {0} leap year!",result==true ? "IS" : "IS NOT");
        }
    }
}
