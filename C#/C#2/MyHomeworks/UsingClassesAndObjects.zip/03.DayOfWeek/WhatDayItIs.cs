﻿/* Write a program that prints to the console which day of the week is today.
Use System.DateTime. */
namespace _03.DayOfWeek
{
    using System;
    class WhatDayItIs
    {
        static void Main(string[] args)
        {
            DateTime today = DateTime.Now;
            Console.WriteLine(today.DayOfWeek);
        }
    }
}
