﻿// Write a program that generates and prints to the console 10 random values in the range [100, 200].
namespace _02.RandomNumbers
{
    using System;
    class TenRandom
    {
        static void Main(string[] args)
        {
            Random rndGeneratedNumber = new Random();
            for (int i = 0; i < 10; i++)
            {
            Console.Write(rndGeneratedNumber.Next(100,201)+" ");
            }
            Console.WriteLine();
        }
    }
}
