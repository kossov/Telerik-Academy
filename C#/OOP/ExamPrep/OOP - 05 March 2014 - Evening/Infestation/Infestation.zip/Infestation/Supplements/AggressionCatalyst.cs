﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation.Supplements
{
    public class AggressionCatalyst : Supplement
    {
        public AggressionCatalyst() : base(0, 0,3) { }
    }
}
