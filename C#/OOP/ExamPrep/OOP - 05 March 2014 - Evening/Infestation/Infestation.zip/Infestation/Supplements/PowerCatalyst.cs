﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation.Supplements
{
    public class PowerCatalyst : Supplement
    {
        public PowerCatalyst() : base(3, 0, 0) { }
    }
}
