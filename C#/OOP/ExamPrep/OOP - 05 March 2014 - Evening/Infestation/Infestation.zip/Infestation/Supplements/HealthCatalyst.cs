﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation.Supplements
{
    public class HealthCatalyst : Supplement
    {
        public HealthCatalyst() : base(0,3, 0) { }
    }
}
