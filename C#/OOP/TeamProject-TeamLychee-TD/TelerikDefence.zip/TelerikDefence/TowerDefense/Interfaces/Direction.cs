﻿namespace TowerDefense.Interfaces
{
    public enum Direction
    {
        LEFT, UP, RIGHT, DOWN
    }
}
