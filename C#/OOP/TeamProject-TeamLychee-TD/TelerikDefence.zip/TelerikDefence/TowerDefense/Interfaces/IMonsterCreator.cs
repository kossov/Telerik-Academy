﻿namespace TowerDefense.Interfaces
{
    public interface IMonsterCreator: IObjectCreator<IMonster>
    {
    }
}
