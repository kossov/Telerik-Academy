﻿namespace TowerDefense.Interfaces
{
    public enum MonsterType
    {
        Bird, Bat, Deamon, Witch, Dragon, 
    }
}
